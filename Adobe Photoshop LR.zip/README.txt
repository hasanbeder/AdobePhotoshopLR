Adobe Photoshop LR Usage Guide

1. Application Location
   - Place the application in the "/Applications" folder
   - Alternatively, you can drag it to the Dock

2. Launching the Application
   - Double-click the application to start
   - It will automatically open in low-resolution mode

3. What is Low-Resolution Mode?
   - Reduces screen scaling
   - Provides a sharper and clearer image
   - Especially useful on Retina displays

4. Troubleshooting
   - If the application doesn't open:
     * Ensure Photoshop is installed
     * Check system permissions

5. Requirements
   - macOS
   - Photoshop must be installed

6. Support
   - If you encounter issues: https://github.com/hasanbeder/AdobePhotoshopLR/issues

7. Contact
   - GitHub: https://github.com/hasanbeder
   - X (Twitter): https://x.com/hasanbeder

Enjoy!
